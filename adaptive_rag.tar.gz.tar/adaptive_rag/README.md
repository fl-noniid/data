# Adaptive RAG Application with LangChain

LangChain 프레임워크를 사용한 Adaptive RAG 애플리케이션입니다. HotpotQA validation dataset을 사용하며, vLLM 백엔드 서버와 통합되어 있습니다. 쿼리를 **single-step RAG**, **multi-step RAG**, **no RAG** 세 가지 전략으로 랜덤하게 라우팅합니다.

## 주요 기능

### 1. **세 가지 RAG 전략**

- **No RAG**: 검색 없이 직접 생성 (Direct Generation)
- **Single-Step RAG**: 한 번의 검색 후 답변 생성
- **Multi-Step RAG**: 다단계 검색 및 반복적 개선을 통한 답변 생성

### 2. **랜덤 라우팅**

각 쿼리는 세 가지 전략 중 하나로 랜덤하게 라우팅되어 다양한 접근 방식의 성능을 비교할 수 있습니다.

### 3. **vLLM 백엔드 통합**

OpenAI 호환 API를 통해 vLLM 서버와 통합되어 효율적인 추론이 가능합니다.

### 4. **HotpotQA Dataset**

Multi-hop 질의응답을 위한 HotpotQA validation dataset을 사용합니다.

## 프로젝트 구조

```
adaptive_rag/
├── main.py                    # 메인 실행 스크립트
├── requirements.txt           # 필요한 패키지 목록
├── models/
│   └── adaptive_rag.py       # Adaptive RAG 모델 구현
├── utils/
│   ├── vllm_client.py        # vLLM 클라이언트
│   ├── data_loader.py        # HotpotQA 데이터 로더
│   └── rag_components.py     # RAG 컴포넌트 (벡터 스토어, 리트리버)
└── data/                      # 데이터 디렉토리 (자동 생성)
```

## 설치 방법

### 1. 의존성 설치

```bash
pip install -r requirements.txt
```

### 2. vLLM 서버 설정

별도의 터미널에서 vLLM 서버를 실행합니다:

```bash
# vLLM 설치
pip install vllm

# vLLM 서버 실행 (예: Llama-2-7b-chat-hf)
python -m vllm.entrypoints.openai.api_server \
    --model meta-llama/Llama-2-7b-chat-hf \
    --port 8000
```

## 사용 방법

### 평가 모드 (Evaluation Mode)

HotpotQA validation dataset에서 샘플을 추출하여 평가합니다:

```bash
python main.py \
    --mode eval \
    --num-samples 100 \
    --output results.json \
    --vllm-url http://localhost:8000/v1 \
    --vllm-model meta-llama/Llama-2-7b-chat-hf
```

**파라미터 설명:**
- `--mode`: 실행 모드 (`eval` 또는 `interactive`)
- `--num-samples`: 평가할 샘플 수
- `--output`: 결과를 저장할 JSON 파일 경로
- `--vllm-url`: vLLM 서버 URL
- `--vllm-model`: vLLM에서 제공하는 모델 이름
- `--embedding-model`: 임베딩 모델 (기본값: `sentence-transformers/all-MiniLM-L6-v2`)

### 인터랙티브 모드 (Interactive Mode)

대화형으로 질문을 입력하고 답변을 받을 수 있습니다:

```bash
python main.py \
    --mode interactive \
    --num-samples 10 \
    --vllm-url http://localhost:8000/v1
```

**사용 예시:**
```
Question: What is the capital of France?
--- Strategy: single_step_rag ---
Answer: Paris
Steps: 1
Retrieved docs: 3

Question: example 0
Using example 0: Were Scott Derrickson and Ed Wood of the same nationality?
--- Strategy: multi_step_rag ---
Answer: ...
```

## 출력 형식

평가 모드에서 생성되는 `results.json` 파일의 형식:

```json
[
  {
    "id": "5a8b57f25542995d1e6f1371",
    "question": "Were Scott Derrickson and Ed Wood of the same nationality?",
    "ground_truth_answer": "yes",
    "predicted_answer": "Yes, both Scott Derrickson and Ed Wood are American.",
    "strategy": "single_step_rag",
    "steps": 1,
    "num_retrieved_docs": 3,
    "level": "medium",
    "type": "comparison"
  }
]
```

## 라우팅 통계

평가 완료 후 각 전략의 사용 빈도가 출력됩니다:

```
=== Routing Statistics ===
no_rag: 33 (33.0%)
single_step_rag: 34 (34.0%)
multi_step_rag: 33 (33.0%)
```

## 구현 세부사항

### RAG 전략

1. **No RAG**: 컨텍스트 없이 직접 질문에 답변
2. **Single-Step RAG**: 
   - 질문에 대해 관련 문서 검색 (top-k=3)
   - 검색된 문서를 컨텍스트로 사용하여 답변 생성
3. **Multi-Step RAG**:
   - 첫 번째 단계: 초기 검색 및 중간 정보 추출
   - 두 번째 단계: 추가 검색 및 최종 답변 생성
   - 반복적 개선을 통한 더 정확한 답변 도출

### 벡터 스토어

- **FAISS**: 효율적인 유사도 검색을 위한 벡터 인덱스
- **HuggingFace Embeddings**: Sentence Transformers 기반 임베딩

### LangChain 통합

- `langchain.vectorstores.FAISS`: 벡터 스토어
- `langchain.embeddings.HuggingFaceEmbeddings`: 임베딩 모델
- `langchain.schema.Document`: 문서 스키마

## 커스터마이징

### 다른 임베딩 모델 사용

```bash
python main.py --embedding-model sentence-transformers/all-mpnet-base-v2
```

### 검색 문서 수 조정

`utils/rag_components.py`에서 `top_k` 파라미터를 수정:

```python
retriever = RAGRetriever(
    embedding_model=embedding_model,
    top_k=5  # 기본값: 3
)
```

### Multi-Step RAG 단계 수 조정

`models/adaptive_rag.py`의 `multi_step_rag_generate` 메서드에서 `num_steps` 파라미터를 수정:

```python
def multi_step_rag_generate(self, query: str, num_steps: int = 3):  # 기본값: 2
    ...
```

## 요구사항

- Python 3.8+
- vLLM 서버 (별도 실행 필요)
- 최소 8GB RAM (임베딩 모델 및 데이터셋 로드)
- GPU (선택사항, vLLM 서버용)

## 라이선스

MIT License

## 참고자료

- [LangChain Documentation](https://python.langchain.com/)
- [vLLM Documentation](https://docs.vllm.ai/)
- [HotpotQA Dataset](https://hotpotqa.github.io/)
- [FAISS Documentation](https://faiss.ai/)
