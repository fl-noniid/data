"""
Main script for Adaptive RAG Application
"""
import argparse
import json
from typing import List, Dict, Any
from tqdm import tqdm

from utils.vllm_client import vLLMClient
from utils.data_loader import HotpotQALoader
from utils.rag_components import RAGRetriever
from models.adaptive_rag import AdaptiveRAG


def setup_rag_system(
    vllm_url: str,
    vllm_model: str,
    embedding_model: str
) -> tuple:
    """
    Setup RAG system components
    
    Args:
        vllm_url: vLLM server URL
        vllm_model: Model name
        embedding_model: Embedding model name
        
    Returns:
        Tuple of (vllm_client, retriever)
    """
    # Initialize vLLM client
    print(f"Connecting to vLLM server at {vllm_url}")
    vllm_client = vLLMClient(
        base_url=vllm_url,
        model_name=vllm_model,
        temperature=0.7,
        max_tokens=512
    )
    
    # Initialize retriever
    retriever = RAGRetriever(
        embedding_model=embedding_model,
        top_k=3
    )
    
    return vllm_client, retriever


def run_evaluation(
    adaptive_rag: AdaptiveRAG,
    data_loader: HotpotQALoader,
    num_samples: int,
    output_file: str
):
    """
    Run evaluation on HotpotQA dataset
    
    Args:
        adaptive_rag: Adaptive RAG system
        data_loader: HotpotQA data loader
        num_samples: Number of samples to evaluate
        output_file: Output JSON file path
    """
    results = []
    
    print(f"\nRunning evaluation on {num_samples} samples...")
    
    for i in tqdm(range(min(num_samples, len(data_loader)))):
        # Get example from dataset
        example = data_loader.get_example(i)
        
        # Build index for this example's context
        documents = data_loader.get_context_documents(i)
        adaptive_rag.retriever.build_index(documents)
        
        # Generate answer using adaptive RAG
        result = adaptive_rag.generate(example["question"])
        
        # Store result with ground truth
        results.append({
            "id": example["id"],
            "question": example["question"],
            "ground_truth_answer": example["answer"],
            "predicted_answer": result["answer"],
            "strategy": result["strategy"],
            "steps": result["steps"],
            "num_retrieved_docs": len(result["retrieved_docs"]),
            "level": example["level"],
            "type": example["type"]
        })
    
    # Save results to file
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print(f"\nResults saved to {output_file}")
    
    # Print statistics
    stats = adaptive_rag.get_stats()
    print("\n=== Routing Statistics ===")
    for strategy, count in stats.items():
        percentage = (count / num_samples) * 100
        print(f"{strategy}: {count} ({percentage:.1f}%)")


def run_interactive(adaptive_rag: AdaptiveRAG, data_loader: HotpotQALoader):
    """
    Run interactive mode
    
    Args:
        adaptive_rag: Adaptive RAG system
        data_loader: HotpotQA data loader
    """
    print("\n=== Interactive Mode ===")
    print("Enter 'quit' to exit")
    print("Enter 'example <idx>' to use a HotpotQA example")
    print("Or enter your own question\n")
    
    while True:
        user_input = input("Question: ").strip()
        
        if user_input.lower() == 'quit':
            break
        
        if user_input.lower().startswith('example'):
            try:
                idx = int(user_input.split()[1])
                example = data_loader.get_example(idx)
                question = example["question"]
                print(f"\nUsing example {idx}: {question}")
                
                # Build index for this example
                documents = data_loader.get_context_documents(idx)
                adaptive_rag.retriever.build_index(documents)
                
            except (IndexError, ValueError):
                print("Invalid example index. Usage: example <idx>")
                continue
        else:
            question = user_input
            # For custom questions, use the first example's context as demo
            documents = data_loader.get_context_documents(0)
            adaptive_rag.retriever.build_index(documents)
        
        # Generate answer
        result = adaptive_rag.generate(question)
        
        print(f"\n--- Strategy: {result['strategy']} ---")
        print(f"Answer: {result['answer']}")
        print(f"Steps: {result['steps']}")
        print(f"Retrieved docs: {len(result['retrieved_docs'])}\n")


def main():
    parser = argparse.ArgumentParser(description="Adaptive RAG Application")
    
    # vLLM settings
    parser.add_argument(
        "--vllm-url",
        type=str,
        default="http://localhost:8000/v1",
        help="vLLM server URL"
    )
    parser.add_argument(
        "--vllm-model",
        type=str,
        default="meta-llama/Llama-2-7b-chat-hf",
        help="Model name served by vLLM"
    )
    
    # Model settings
    parser.add_argument(
        "--embedding-model",
        type=str,
        default="sentence-transformers/all-MiniLM-L6-v2",
        help="Embedding model for retrieval"
    )
    
    # Dataset settings
    parser.add_argument(
        "--num-samples",
        type=int,
        default=100,
        help="Number of samples to load from HotpotQA"
    )
    
    # Evaluation settings
    parser.add_argument(
        "--mode",
        type=str,
        choices=["eval", "interactive"],
        default="eval",
        help="Run mode: eval or interactive"
    )
    parser.add_argument(
        "--output",
        type=str,
        default="results.json",
        help="Output file for evaluation results"
    )
    
    args = parser.parse_args()
    
    # Load HotpotQA dataset
    data_loader = HotpotQALoader(
        split="validation",
        sample_size=args.num_samples
    )
    
    # Setup RAG system
    vllm_client, retriever = setup_rag_system(
        vllm_url=args.vllm_url,
        vllm_model=args.vllm_model,
        embedding_model=args.embedding_model
    )
    
    # Initialize Adaptive RAG
    adaptive_rag = AdaptiveRAG(
        vllm_client=vllm_client,
        retriever=retriever,
        routing_strategy="random"
    )
    
    # Run selected mode
    if args.mode == "eval":
        run_evaluation(
            adaptive_rag=adaptive_rag,
            data_loader=data_loader,
            num_samples=args.num_samples,
            output_file=args.output
        )
    else:
        run_interactive(
            adaptive_rag=adaptive_rag,
            data_loader=data_loader
        )


if __name__ == "__main__":
    main()
