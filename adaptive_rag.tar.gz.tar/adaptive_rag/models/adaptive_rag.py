"""
Adaptive RAG Application with Random Routing Strategy
"""
import random
from typing import Dict, Any, List, Optional
from enum import Enum
from langchain.schema import Document

from utils.vllm_client import vLLMClient
from utils.rag_components import RAGRetriever, format_retrieved_context


class RAGStrategy(Enum):
    """RAG routing strategies"""
    NO_RAG = "no_rag"
    SINGLE_STEP_RAG = "single_step_rag"
    MULTI_STEP_RAG = "multi_step_rag"


class AdaptiveRAG:
    """Adaptive RAG system with random routing"""
    
    def __init__(
        self,
        vllm_client: vLLMClient,
        retriever: RAGRetriever,
        routing_strategy: str = "random"
    ):
        """
        Initialize Adaptive RAG system
        
        Args:
            vllm_client: vLLM client for generation
            retriever: RAG retriever for document retrieval
            routing_strategy: Strategy for routing queries (currently only 'random')
        """
        self.vllm_client = vllm_client
        self.retriever = retriever
        self.routing_strategy = routing_strategy
        
        # Statistics tracking
        self.stats = {
            RAGStrategy.NO_RAG: 0,
            RAGStrategy.SINGLE_STEP_RAG: 0,
            RAGStrategy.MULTI_STEP_RAG: 0
        }
    
    def route_query(self, query: str) -> RAGStrategy:
        """
        Route query to appropriate RAG strategy
        
        Args:
            query: Input query
            
        Returns:
            Selected RAG strategy
        """
        if self.routing_strategy == "random":
            # Randomly select one of the three strategies
            strategy = random.choice(list(RAGStrategy))
            self.stats[strategy] += 1
            return strategy
        else:
            raise ValueError(f"Unknown routing strategy: {self.routing_strategy}")
    
    def no_rag_generate(self, query: str) -> Dict[str, Any]:
        """
        Generate answer without RAG (direct generation)
        
        Args:
            query: Input query
            
        Returns:
            Dictionary with answer and metadata
        """
        prompt = f"""Answer the following question directly and concisely.

Question: {query}

Answer:"""
        
        answer = self.vllm_client.generate(prompt, max_tokens=256)
        
        return {
            "strategy": RAGStrategy.NO_RAG.value,
            "answer": answer,
            "retrieved_docs": [],
            "steps": 0
        }
    
    def single_step_rag_generate(self, query: str) -> Dict[str, Any]:
        """
        Generate answer with single-step RAG
        
        Args:
            query: Input query
            
        Returns:
            Dictionary with answer and metadata
        """
        # Step 1: Retrieve relevant documents
        retrieved_docs = self.retriever.retrieve(query, k=3)
        context = format_retrieved_context(retrieved_docs)
        
        # Step 2: Generate answer with context
        prompt = f"""Answer the following question based on the provided context.

Context:
{context}

Question: {query}

Answer:"""
        
        answer = self.vllm_client.generate(prompt, max_tokens=256)
        
        return {
            "strategy": RAGStrategy.SINGLE_STEP_RAG.value,
            "answer": answer,
            "retrieved_docs": [doc.page_content for doc in retrieved_docs],
            "steps": 1
        }
    
    def multi_step_rag_generate(self, query: str, num_steps: int = 2) -> Dict[str, Any]:
        """
        Generate answer with multi-step RAG (iterative refinement)
        
        Args:
            query: Input query
            num_steps: Number of retrieval-generation steps
            
        Returns:
            Dictionary with answer and metadata
        """
        all_retrieved_docs = []
        current_query = query
        
        for step in range(num_steps):
            # Retrieve documents for current query
            retrieved_docs = self.retriever.retrieve(current_query, k=2)
            all_retrieved_docs.extend(retrieved_docs)
            
            if step < num_steps - 1:
                # Intermediate step: generate follow-up query or reasoning
                context = format_retrieved_context(retrieved_docs)
                prompt = f"""Based on the context below, provide key information relevant to answering this question: {query}

Context:
{context}

Key Information:"""
                
                intermediate_result = self.vllm_client.generate(prompt, max_tokens=128)
                
                # Update query for next iteration
                current_query = f"{query}\n\nAdditional context: {intermediate_result}"
            else:
                # Final step: generate final answer
                context = format_retrieved_context(all_retrieved_docs)
                prompt = f"""Answer the following question based on all the provided context.

Context:
{context}

Question: {query}

Answer:"""
                
                answer = self.vllm_client.generate(prompt, max_tokens=256)
        
        return {
            "strategy": RAGStrategy.MULTI_STEP_RAG.value,
            "answer": answer,
            "retrieved_docs": [doc.page_content for doc in all_retrieved_docs],
            "steps": num_steps
        }
    
    def generate(self, query: str) -> Dict[str, Any]:
        """
        Generate answer using adaptive routing
        
        Args:
            query: Input query
            
        Returns:
            Dictionary with answer and metadata
        """
        # Route query to appropriate strategy
        strategy = self.route_query(query)
        
        # Execute selected strategy
        if strategy == RAGStrategy.NO_RAG:
            result = self.no_rag_generate(query)
        elif strategy == RAGStrategy.SINGLE_STEP_RAG:
            result = self.single_step_rag_generate(query)
        elif strategy == RAGStrategy.MULTI_STEP_RAG:
            result = self.multi_step_rag_generate(query)
        else:
            raise ValueError(f"Unknown strategy: {strategy}")
        
        result["query"] = query
        return result
    
    def get_stats(self) -> Dict[str, int]:
        """Get routing statistics"""
        return {k.value: v for k, v in self.stats.items()}
