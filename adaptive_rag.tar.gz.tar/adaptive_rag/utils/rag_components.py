"""
RAG Components: Vector Store and Retriever
"""
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.schema import Document
from typing import List, Dict, Any
import numpy as np


class RAGRetriever:
    """Retriever component for RAG system"""
    
    def __init__(
        self,
        embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2",
        top_k: int = 3
    ):
        """
        Initialize RAG retriever
        
        Args:
            embedding_model: HuggingFace embedding model name
            top_k: Number of documents to retrieve
        """
        print(f"Loading embedding model: {embedding_model}")
        self.embeddings = HuggingFaceEmbeddings(
            model_name=embedding_model,
            model_kwargs={'device': 'cpu'}
        )
        self.top_k = top_k
        self.vector_store = None
    
    def build_index(self, documents: List[Dict[str, str]]):
        """
        Build vector store index from documents
        
        Args:
            documents: List of document dicts with 'title' and 'content'
        """
        # Convert to LangChain Document format
        docs = [
            Document(
                page_content=doc["full_text"],
                metadata={"title": doc["title"]}
            )
            for doc in documents
        ]
        
        # Build FAISS index
        self.vector_store = FAISS.from_documents(docs, self.embeddings)
        print(f"Built vector store with {len(docs)} documents")
    
    def retrieve(self, query: str, k: int = None) -> List[Document]:
        """
        Retrieve relevant documents for a query
        
        Args:
            query: Query string
            k: Number of documents to retrieve (override default)
            
        Returns:
            List of relevant documents
        """
        if self.vector_store is None:
            raise ValueError("Vector store not initialized. Call build_index first.")
        
        k = k or self.top_k
        docs = self.vector_store.similarity_search(query, k=k)
        return docs
    
    def retrieve_with_scores(self, query: str, k: int = None) -> List[tuple]:
        """
        Retrieve relevant documents with similarity scores
        
        Args:
            query: Query string
            k: Number of documents to retrieve (override default)
            
        Returns:
            List of (document, score) tuples
        """
        if self.vector_store is None:
            raise ValueError("Vector store not initialized. Call build_index first.")
        
        k = k or self.top_k
        docs_and_scores = self.vector_store.similarity_search_with_score(query, k=k)
        return docs_and_scores


def format_retrieved_context(documents: List[Document]) -> str:
    """
    Format retrieved documents into a context string
    
    Args:
        documents: List of retrieved documents
        
    Returns:
        Formatted context string
    """
    context_parts = []
    for i, doc in enumerate(documents, 1):
        context_parts.append(f"Document {i}:\n{doc.page_content}\n")
    
    return "\n".join(context_parts)
