"""
HotpotQA Dataset Loader
"""
from datasets import load_dataset
from typing import List, Dict, Any, Optional
import random


class HotpotQALoader:
    """Loader for HotpotQA validation dataset"""
    
    def __init__(self, split: str = "validation", sample_size: Optional[int] = None):
        """
        Initialize HotpotQA loader
        
        Args:
            split: Dataset split to load (train/validation)
            sample_size: Number of samples to load (None for all)
        """
        print(f"Loading HotpotQA {split} dataset...")
        self.dataset = load_dataset("hotpot_qa", "distractor", split=split)
        
        if sample_size:
            # Randomly sample if sample_size is specified
            indices = random.sample(range(len(self.dataset)), min(sample_size, len(self.dataset)))
            self.dataset = self.dataset.select(indices)
        
        print(f"Loaded {len(self.dataset)} examples")
    
    def get_example(self, idx: int) -> Dict[str, Any]:
        """
        Get a single example from the dataset
        
        Args:
            idx: Index of the example
            
        Returns:
            Dictionary containing question, answer, context, and supporting facts
        """
        example = self.dataset[idx]
        
        return {
            "id": example["id"],
            "question": example["question"],
            "answer": example["answer"],
            "context": example["context"],
            "supporting_facts": example["supporting_facts"],
            "level": example["level"],
            "type": example["type"]
        }
    
    def get_context_documents(self, idx: int) -> List[Dict[str, str]]:
        """
        Extract context documents from an example
        
        Args:
            idx: Index of the example
            
        Returns:
            List of documents with title and content
        """
        example = self.dataset[idx]
        documents = []
        
        # HotpotQA context is a list of [title, sentences]
        for title, sentences in zip(example["context"]["title"], example["context"]["sentences"]):
            content = " ".join(sentences)
            documents.append({
                "title": title,
                "content": content,
                "full_text": f"{title}: {content}"
            })
        
        return documents
    
    def __len__(self) -> int:
        """Return the number of examples in the dataset"""
        return len(self.dataset)
    
    def __iter__(self):
        """Iterate over the dataset"""
        for i in range(len(self)):
            yield self.get_example(i)
